"""
ChatBI Web 应用 - 使用 Streamlit 提供网页界面
"""

import streamlit as st
import pandas as pd
import base64
from io import BytesIO
import matplotlib.pyplot as plt
import traceback
import sys
import os
from app.config import DB_CONFIG
from app.query_engine import QueryEngine

# 设置页面配置
st.set_page_config(
    page_title="超市销售数据分析 ChatBI",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 自定义CSS样式
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #424242;
        margin-bottom: 1rem;
    }
    .result-container {
        background-color: #f0f2f6;
        padding: 1.5rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .stDataFrame {
        margin-top: 1rem;
    }
    .error-message {
        background-color: #ffebee;
        color: #c62828;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# 添加调试信息显示区域
debug_expander = st.expander("调试信息", expanded=False)
with debug_expander:
    st.write("当前工作目录:", os.getcwd())
    st.write("Python路径:", sys.path)
    st.write("DB配置:", DB_CONFIG)

# 初始化会话状态
if 'initialized' not in st.session_state:
    st.session_state.initialized = False

if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

# 初始化查询引擎
if not st.session_state.initialized:
    with st.spinner('正在初始化系统，请稍候...'):
        try:
            # 确保数据文件存在
            from app.config import DATA_PATH
            if not os.path.exists(DATA_PATH):
                st.error(f"数据文件不存在: {DATA_PATH}")
                st.stop()
            
            # 初始化查询引擎
            st.session_state.query_engine = QueryEngine(use_db=DB_CONFIG["use_db"])
            st.session_state.initialized = True
            st.success('系统初始化完成！')
        except Exception as e:
            st.error(f"系统初始化失败: {str(e)}")
            st.code(traceback.format_exc())
            st.stop()

# 页面标题
st.markdown('<div class="main-header">超市销售数据分析 ChatBI</div>', unsafe_allow_html=True)

# 侧边栏
with st.sidebar:
    st.markdown("## 关于")
    st.info(
        "这是一个基于自然语言处理的超市销售数据分析系统。"
        "您可以用自然语言提问，系统会自动分析数据并给出答案。"
    )
    
    st.markdown("## 示例问题")
    example_questions = [
        "哪个城市的销售额最高？",
        "显示不同产品线的平均评分",
        "绘制每月销售额趋势图",
        "哪种支付方式最受欢迎？",
        "男性和女性客户在购买行为上有什么区别？"
    ]
    
    # 使用唯一键来避免按钮冲突
    for i, q in enumerate(example_questions):
        if st.button(q, key=f"example_q_{i}"):
            # 直接设置会话状态中的用户输入
            st.session_state.user_input = q
            st.session_state.last_query = ""  # 重置上次查询记录，确保能处理
            st.experimental_rerun()  # 强制重新渲染
    
    st.markdown("## 设置")
    if st.button("清除聊天历史"):
        st.session_state.chat_history = []
        st.success("聊天历史已清除！")
    
    # 添加重新初始化系统按钮
    if st.button("重新初始化系统"):
        st.session_state.pop('query_engine', None)
        st.experimental_rerun()

# 用户输入和提交
col1, col2 = st.columns([4, 1])
with col1:
    user_input = st.text_input(
        "请输入您的问题:",
        key="user_input",
        placeholder="例如：哪个城市的销售额最高？"
    )
with col2:
    submit_button = st.button("提交", key="submit_button")

# 处理用户输入
if submit_button or (user_input and user_input != st.session_state.get('last_query', '')):
    if user_input:
        # 记录当前查询，避免重复处理
        st.session_state.last_query = user_input
        
        with st.spinner('正在分析您的问题...'):
            try:
                # 处理查询
                result = st.session_state.query_engine.process_query(user_input)
                
                # 添加到聊天历史
                st.session_state.chat_history.append({
                    "query": user_input,
                    "result": result,
                    "error": None
                })
                
                # 清空输入框 (通过设置会话状态)
                st.session_state.user_input = ""
            except Exception as e:
                # 捕获并记录错误
                error_msg = str(e)
                error_traceback = traceback.format_exc()
                st.error(f"处理查询时出错: {error_msg}")
                st.code(error_traceback)
                
                # 添加错误信息到聊天历史
                st.session_state.chat_history.append({
                    "query": user_input,
                    "result": None,
                    "error": {
                        "message": error_msg,
                        "traceback": error_traceback
                    }
                })
        
        # 强制重新渲染页面
        st.experimental_rerun()

# 显示聊天历史
for i, chat in enumerate(reversed(st.session_state.chat_history)):
    st.markdown(f"### 问题 {len(st.session_state.chat_history) - i}")
    st.markdown(f"**Q:** {chat['query']}")
    
    # 检查是否有错误
    if chat.get("error"):
        st.markdown('<div class="error-message">', unsafe_allow_html=True)
        st.markdown(f"**错误:** {chat['error']['message']}")
        with st.expander("查看详细错误信息"):
            st.code(chat['error']['traceback'])
        st.markdown('</div>', unsafe_allow_html=True)
        st.markdown("---")
        continue
    
    result = chat['result']
    if not result:
        st.warning("未能获取结果")
        st.markdown("---")
        continue
    
    st.markdown('<div class="result-container">', unsafe_allow_html=True)
    
    try:
        if result["type"] == "text":
            st.markdown(f"**A:** {result['answer']}")
            
            # 如果结果是DataFrame，显示数据表格
            if hasattr(result.get("data", None), "head"):
                st.markdown("#### 数据预览")
                st.dataframe(result["data"].head(10))
        
        elif result["type"] == "visualization":
            st.markdown(f"**A:** {result.get('answer', '生成了可视化结果')}")
            
            # 显示可视化
            if result.get("visualization"):
                st.markdown("#### 可视化结果")
                try:
                    img_data = base64.b64decode(result["visualization"])
                    st.image(img_data, use_column_width=True)
                    
                    # 添加下载按钮
                    buf = BytesIO(img_data)
                    st.download_button(
                        label="下载图片",
                        data=buf,
                        file_name="visualization.png",
                        mime="image/png"
                    )
                except Exception as e:
                    st.error(f"显示可视化时出错: {str(e)}")
                
                # 如果有数据，也显示数据表格
                if hasattr(result.get("data", None), "head"):
                    st.markdown("#### 数据预览")
                    st.dataframe(result["data"].head(10))
        else:
            st.warning(f"未知的结果类型: {result.get('type', 'unknown')}")
    except Exception as e:
        st.error(f"显示结果时出错: {str(e)}")
        st.code(traceback.format_exc())
    
    st.markdown('</div>', unsafe_allow_html=True)
    st.markdown("---")

# 页脚
st.markdown("""
<div style="text-align: center; margin-top: 3rem; color: #9e9e9e;">
    <p>超市销售数据分析 ChatBI © 2023</p>
</div>
""", unsafe_allow_html=True)