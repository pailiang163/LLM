"""
数据库模块，处理MySQL数据库连接和操作
"""

import pymysql
from sqlalchemy import create_engine, text
import pandas as pd

def create_connection(db_config):
    """创建数据库连接"""
    try:
        connection = pymysql.connect(
            host=db_config['host'],
            user=db_config['user'],
            password=db_config['password'],
            database=db_config['database']
        )
        return connection
    except Exception as e:
        print(f"数据库连接失败: {str(e)}")
        return None

def create_table(connection, table_name):
    """创建销售数据表"""
    try:
        cursor = connection.cursor()
        
        # 创建表的SQL语句
        create_table_sql = f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INT AUTO_INCREMENT PRIMARY KEY,
            invoice_id VARCHAR(20),
            branch VARCHAR(10),
            city VARCHAR(20),
            customer_type VARCHAR(20),
            gender VARCHAR(10),
            product_line VARCHAR(50),
            unit_price FLOAT,
            quantity INT,
            tax FLOAT,
            total FLOAT,
            date DATE,
            time TIME,
            payment VARCHAR(20),
            cogs FLOAT,
            gross_margin_percentage FLOAT,
            gross_income FLOAT,
            rating FLOAT,
            month INT,
            day INT,
            weekday VARCHAR(20)
        )
        """
        
        cursor.execute(create_table_sql)
        connection.commit()
        print(f"表 {table_name} 创建成功")
        return True
    except Exception as e:
        print(f"创建表时出错: {str(e)}")
        return False

def insert_data(connection, table_name, data):
    """将数据插入到表中"""
    try:
        # 创建SQLAlchemy引擎
        engine = create_engine(
            f"mysql+pymysql://{connection.user}:{connection.password}@{connection.host}/{connection.db}"
        )
        
        # 将DataFrame列名转换为小写并替换空格为下划线
        data.columns = [col.lower().replace(' ', '_').replace('%', 'percentage') for col in data.columns]
        
        # 将数据写入数据库
        data.to_sql(table_name, engine, if_exists='replace', index=False)
        
        print(f"成功插入 {len(data)} 行数据到表 {table_name}")
        return True
    except Exception as e:
        print(f"插入数据时出错: {str(e)}")
        return False

def execute_query(connection, query):
    """执行SQL查询"""
    try:
        # 创建SQLAlchemy引擎
        engine = create_engine(
            f"mysql+pymysql://{connection.user}:{connection.password}@{connection.host}/{connection.db}"
        )
        
        # 执行查询
        with engine.connect() as conn:
            result = conn.execute(text(query))
            data = result.fetchall()
            
            # 获取列名
            columns = result.keys()
            
            # 创建DataFrame
            df = pd.DataFrame(data, columns=columns)
            return df
    except Exception as e:
        print(f"执行查询时出错: {str(e)}")
        return None