"""
主程序，提供命令行界面与ChatBI交互
"""

import os
import sys
import traceback
import pandas as pd
from app.config import DB_CONFIG, DATA_PATH
from app.query_engine import QueryEngine

def clear_screen():
    """清除屏幕"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """打印应用标题"""
    print("=" * 50)
    print("超市销售数据分析 ChatBI")
    print("=" * 50)
    print("输入您的问题，或输入 'exit' 退出")
    print("-" * 50)

def main():
    """主函数"""
    clear_screen()
    print_header()
    
    # 检查数据文件是否存在
    if not os.path.exists(DATA_PATH):
        print(f"错误: 数据文件不存在: {DATA_PATH}")
        return
    
    # 初始化查询引擎
    print("正在初始化系统，请稍候...")
    try:
        # 打印调试信息
        print(f"数据文件路径: {DATA_PATH}")
        print(f"数据库配置: {DB_CONFIG}")
        
        # 初始化查询引擎
        query_engine = QueryEngine(use_db=DB_CONFIG["use_db"])
        print("系统初始化完成！")
    except Exception as e:
        print(f"系统初始化失败: {str(e)}")
        print("详细错误信息:")
        traceback.print_exc()
        return
    
    # 主循环
    while True:
        # 获取用户输入
        user_query = input("\n请输入您的问题: ")
        
        # 检查是否退出
        if user_query.lower() in ['exit', 'quit', '退出']:
            print("感谢使用，再见！")
            break
        
        # 处理空输入
        if not user_query.strip():
            continue
        
        print("\n正在分析您的问题...")
        
        # 处理查询
        try:
            # 打印调试信息
            print(f"处理查询: {user_query}")
            
            # 处理查询
            result = query_engine.process_query(user_query)
            
            # 显示结果
            print("\n" + "=" * 50)
            print("查询结果:")
            print("-" * 50)
            
            if result["type"] == "text":
                print(result["answer"])
                
                # 如果结果是DataFrame，显示前5行
                if hasattr(result["data"], "head"):
                    print("\n数据预览:")
                    print(result["data"].head().to_string())
            
            elif result["type"] == "visualization":
                print(result["answer"] if "answer" in result else "生成了可视化结果")
                print("\n可视化已生成。请查看输出目录中的图像文件。")
                
                # 保存可视化到文件
                if result["visualization"]:
                    import base64
                    img_data = base64.b64decode(result["visualization"])
                    img_file = "visualization.png"
                    with open(img_file, "wb") as f:
                        f.write(img_data)
                    print(f"可视化已保存到: {img_file}")
            
            print("=" * 50)
        except Exception as e:
            print(f"\n处理查询时出错: {str(e)}")
            print("详细错误信息:")
            traceback.print_exc()

if __name__ == "__main__":
    main()