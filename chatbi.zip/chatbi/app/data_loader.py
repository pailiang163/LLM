"""
数据加载模块，负责从CSV加载数据或将数据导入MySQL
"""

import pandas as pd
from .config import DATA_PATH
from .database import create_connection, create_table, insert_data

class DataLoader:
    def __init__(self, use_db=False):
        """
        初始化数据加载器
        
        Args:
            use_db: 是否使用数据库存储数据
        """
        self.use_db = use_db
        self.data = None
        
    def load_data(self):
        """加载CSV数据"""
        try:
            # 读取CSV文件
            self.data = pd.read_csv(DATA_PATH)
            
            # 处理日期列
            self.data['Date'] = pd.to_datetime(self.data['Date'], format='%m/%d/%Y')
            
            # 添加额外的分析列
            self.data['Month'] = self.data['Date'].dt.month
            self.data['Day'] = self.data['Date'].dt.day
            self.data['Weekday'] = self.data['Date'].dt.day_name()
            
            print(f"成功加载数据: {len(self.data)} 行")
            return self.data
        except Exception as e:
            print(f"加载数据时出错: {str(e)}")
            return None
    
    def load_to_database(self, db_config):
        """将数据加载到MySQL数据库"""
        if self.data is None:
            self.load_data()
            
        if self.data is not None:
            try:
                # 创建数据库连接
                conn = create_connection(db_config)
                
                # 创建表
                create_table(conn, db_config['table_name'])
                
                # 插入数据
                insert_data(conn, db_config['table_name'], self.data)
                
                print(f"成功将数据导入到数据库表 {db_config['table_name']}")
                return True
            except Exception as e:
                print(f"导入数据到数据库时出错: {str(e)}")
                return False
        return False
    
    def get_data_schema(self):
        """获取数据结构信息"""
        if self.data is None:
            self.load_data()
            
        if self.data is not None:
            schema = {}
            for col in self.data.columns:
                schema[col] = str(self.data[col].dtype)
            return schema
        return None
    
    def get_data_sample(self, n=5):
        """获取数据样本"""
        if self.data is None:
            self.load_data()
            
        if self.data is not None:
            return self.data.head(n).to_dict('records')
        return None