"""
配置文件，包含系统参数
"""

import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 数据文件路径
DATA_PATH = r"supermarket_sales.csv"

# 数据库配置
DB_CONFIG = {
    "use_db": False,  # 设置为 True 使用 MySQL，False 使用 CSV
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "supermarket"),
    "table_name": "sales"
}

# Ollama 配置
OLLAMA_CONFIG = {
    "model_name": "deepseek-r1:7b",
    "base_url": "http://localhost:11434"
}

# 应用配置
APP_CONFIG = {
    "temperature": 0.1,
    "max_tokens": 1000
}