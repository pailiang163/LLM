"""
超市销售数据分析 ChatBI 应用包

此包包含以下模块:
- config: 配置文件，包含系统参数
- data_loader: 数据加载模块，负责从CSV加载数据或将数据导入MySQL
- database: 数据库模块，处理MySQL数据库连接和操作
- model: 模型模块，处理与Ollama的交互
- query_engine: 查询引擎模块，处理自然语言查询
- visualization: 可视化模块，处理数据可视化
"""

__version__ = '1.0.0'