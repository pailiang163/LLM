"""
模型模块，处理与Ollama的交互
"""

from langchain.llms import Ollama
from langchain.callbacks.manager import CallbackManager
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from .config import OLLAMA_CONFIG, APP_CONFIG

class ModelManager:
    def __init__(self):
        """初始化模型管理器"""
        self.model = None
        self.initialize_model()
        
    def initialize_model(self):
        """初始化Ollama模型"""
        try:
            # 设置回调管理器以支持流式输出
            callback_manager = CallbackManager([StreamingStdOutCallbackHandler()])
            
            # 初始化Ollama模型
            self.model = Ollama(
                model=OLLAMA_CONFIG["model_name"],
                base_url=OLLAMA_CONFIG["base_url"],
                callback_manager=callback_manager,
                temperature=APP_CONFIG["temperature"],
                num_predict=APP_CONFIG["max_tokens"]
            )
            
            print(f"成功初始化模型 {OLLAMA_CONFIG['model_name']}")
            return True
        except Exception as e:
            print(f"初始化模型时出错: {str(e)}")
            return False
    
    def get_model(self):
        """获取模型实例"""
        if self.model is None:
            self.initialize_model()
        return self.model