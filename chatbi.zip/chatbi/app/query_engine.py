"""
查询引擎模块，处理自然语言查询
"""

import pandas as pd
import traceback  # Added import for traceback module
import re  # Added import for regular expressions
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from .model import ModelManager
from .data_loader import DataLoader
from .database import create_connection, execute_query
from .config import DB_CONFIG
from .visualization import create_visualization

class QueryEngine:
    def __init__(self, use_db=False):
        """
        初始化查询引擎
        
        Args:
            use_db: 是否使用数据库
        """
        self.use_db = use_db
        self.model_manager = ModelManager()
        self.data_loader = DataLoader(use_db)
        
        # 加载数据
        self.data = self.data_loader.load_data()
        
        # 如果使用数据库，则将数据导入数据库
        if use_db:
            self.data_loader.load_to_database(DB_CONFIG)
            self.db_connection = create_connection(DB_CONFIG)
        
        # 获取数据结构
        self.schema = self.data_loader.get_data_schema()
        
        # 获取数据样本
        self.sample = self.data_loader.get_data_sample()
        
        # 初始化LLM
        self.llm = self.model_manager.get_model()
    
    def generate_sql_query(self, user_query):
        """根据用户查询生成SQL查询"""
        # 创建SQL生成提示模板
        sql_prompt = PromptTemplate(
            input_variables=["schema", "sample", "query"],
            template="""
            你是一个SQL专家。根据以下信息，生成一个SQL查询来回答问题。
            
            数据结构:
            {schema}
            
            数据样本:
            {sample}
            
            用户问题: {query}
            
            请生成一个有效的SQL查询来回答这个问题。只返回SQL查询，不要有其他解释。
            请确保使用英文标点符号，不要使用中文标点符号如"，"、"："等。
            
            SQL查询:
            """
        )
        
        # 创建LLM链
        sql_chain = LLMChain(llm=self.llm, prompt=sql_prompt)
        
        # 生成SQL查询
        sql_query = sql_chain.run({
            "schema": self.schema,
            "sample": self.sample[:3],
            "query": user_query
        })
        
        # 清理SQL查询
        sql_query = sql_query.strip()
        if sql_query.startswith("```sql"):
            sql_query = sql_query[7:]
        if sql_query.endswith("```"):
            sql_query = sql_query[:-3]
        
        # 替换中文标点符号为英文标点符号
        punctuation_map = {
            '，': ',',
            '。': '.',
            '：': ':',
            '；': ';',
            '"': '"',
            '"': '"',
            ''': "'",
            ''': "'",
            '（': '(',
            '）': ')',
            '【': '[',
            '】': ']',
            '《': '<',
            '》': '>',
            '！': '!',
            '？': '?',
            '、': ',',
            '…': '...'
        }
        
        for ch, en in punctuation_map.items():
            sql_query = sql_query.replace(ch, en)
        
        return sql_query.strip()
    
    def generate_pandas_code(self, user_query):
        """根据用户查询生成Pandas代码"""
        # 创建Pandas代码生成提示模板
        pandas_prompt = PromptTemplate(
            input_variables=["schema", "sample", "query"],
            template="""
            你是一个Python和Pandas专家。根据以下信息，生成Pandas代码来回答问题。
            
            数据结构:
            {schema}
            
            数据样本:
            {sample}
            
            用户问题: {query}
            
            请直接生成纯Python代码，不要包含任何解释、思考过程或注释。代码必须是可以直接执行的有效Python语法。
            假设数据已经加载到名为'df'的DataFrame中。
            不要输出任何自然语言内容，只输出可执行的Python代码。
            不要使用三重反引号或其他标记。
            
            示例输出格式:
            result = df.groupby('Column')['Value'].sum()
            """
        )
        
        # 创建LLM链
        pandas_chain = LLMChain(llm=self.llm, prompt=pandas_prompt)
        
        # 生成Pandas代码
        try:
            pandas_code = pandas_chain.run({
                "schema": self.schema,
                "sample": self.sample[:3],
                "query": user_query
            })
            
            # 清理Pandas代码
            pandas_code = pandas_code.strip()
            
            # 移除代码块标记
            if pandas_code.startswith("```python"):
                pandas_code = pandas_code[10:]
            elif pandas_code.startswith("```"):
                pandas_code = pandas_code[3:]
            if pandas_code.endswith("```"):
                pandas_code = pandas_code[:-3]
            
            # 移除所有非代码内容
            # 首先尝试找到第一行有效的Python代码
            lines = pandas_code.split('\n')
            start_index = 0
            for i, line in enumerate(lines):
                line = line.strip()
                # 跳过空行和注释行
                if not line or line.startswith('#'):
                    continue
                # 检查是否是自然语言（通常以中文字符开头）
                if re.match(r'[\u4e00-\u9fff]', line):
                    continue
                # 如果行包含赋值、函数调用或导入语句，可能是代码
                if ('=' in line or '(' in line or line.startswith('import') or 
                    line.startswith('from') or line.startswith('def')):
                    start_index = i
                    break
            
            # 只保留从第一行有效代码开始的内容
            lines = lines[start_index:]
            
            # 进一步清理每一行
            cleaned_lines = []
            for line in lines:
                # 跳过自然语言行
                if re.match(r'[\u4e00-\u9fff]', line.strip()):
                    continue
                # 跳过XML标签行
                if re.search(r'<[^>]+>', line) and not ('<=' in line or '>=' in line or '!=' in line):
                    continue
                # 替换中文标点
                for ch, en in self.get_punctuation_map().items():
                    line = line.replace(ch, en)
                cleaned_lines.append(line)
            
            # 确保代码以有效的Python语句结束
            final_code = '\n'.join(cleaned_lines).strip()
            
            # 添加一个默认的结果变量，以防生成的代码没有明确的结果变量
            if not any(re.search(r'^\s*(result|answer|output)\s*=', line) for line in cleaned_lines):
                # 检查最后一行是否可能是一个表达式结果
                if cleaned_lines and not cleaned_lines[-1].strip().endswith(':') and '=' not in cleaned_lines[-1]:
                    last_line = cleaned_lines[-1].strip()
                    # 将最后一行的表达式赋值给result变量
                    cleaned_lines[-1] = f"result = {last_line}"
                    final_code = '\n'.join(cleaned_lines).strip()
                else:
                    # 如果没有明显的结果表达式，添加一个基本的结果变量
                    final_code += "\n\n# 确保有结果变量\nif 'result' not in locals():\n    result = None"
            
            return final_code
            
        except Exception as e:
            print(f"生成Pandas代码时出错: {str(e)}")
            # 返回一个简单的默认代码，确保至少有一些可执行的内容
            return "result = df.head()"
        
    def get_punctuation_map(self):
        """返回中英文标点符号映射"""
        return {
            '，': ',',
            '。': '.',
            '：': ':',
            '；': ';',
            '"': '"',
            '"': '"',
            ''': "'",
            ''': "'",
            '（': '(',
            '）': ')',
            '【': '[',
            '】': ']',
            '《': '<',
            '》': '>',
            '！': '!',
            '？': '?',
            '、': ',',
            '…': '...'
        }
    
    def execute_pandas_query(self, pandas_code):
        """执行Pandas查询代码"""
        try:
            # 创建本地变量df引用数据
            df = self.data
            
            # 打印要执行的代码（调试用）
            print("执行的Pandas代码:")
            print(pandas_code)
            
            # 添加必要的导入
            local_vars = {
                "df": df, 
                "pd": pd,
                "np": __import__('numpy'),
                "plt": __import__('matplotlib.pyplot'),
                "sns": __import__('seaborn')
            }
            
            # 执行代码并捕获结果
            exec(pandas_code, globals(), local_vars)
            
            # 尝试获取结果
            result = None
            # 首先检查是否有名为'result'的变量
            if 'result' in local_vars:
                result = local_vars['result']
            else:
                # 如果没有，查找其他可能的结果变量
                for var_name, var_value in local_vars.items():
                    if var_name not in ["df", "pd", "np", "plt", "sns", "__builtins__"]:
                        result = var_value
                        break
            
            # 如果结果是None但有图表，则返回数据框
            if result is None and 'plt' in local_vars and local_vars['plt'].get_fignums():
                result = df
            
            return result
        except Exception as e:
            print(f"执行Pandas代码时出错: {str(e)}")
            print(f"问题代码: {pandas_code}")
            traceback.print_exc()
            
            # 尝试执行一个简单的查询作为后备方案
            try:
                print("尝试执行后备查询...")
                if "City" in df.columns and "Quantity" in df.columns:
                    result = df.groupby('City')['Quantity'].sum().sort_values(ascending=False)
                    print("后备查询成功")
                    return result
                else:
                    print("无法执行后备查询，列名不匹配")
                    return df.head()
            except Exception as backup_error:
                print(f"后备查询也失败了: {str(backup_error)}")
                return df.head()
    
    def execute_sql_query(self, sql_query):
        """执行SQL查询"""
        if not self.use_db:
            print("未启用数据库，无法执行SQL查询")
            return None
        
        try:
            result = execute_query(self.db_connection, sql_query)
            return result
        except Exception as e:
            print(f"执行SQL查询时出错: {str(e)}")
            return None
    
    def process_query(self, user_query):
        """处理用户查询"""
        # 确定是否需要可视化
        needs_visualization = any(keyword in user_query.lower() for keyword in 
                                ["图", "图表", "可视化", "趋势", "比较", "分布", "展示", "plot", "chart", "graph", "visualize"])
        
        # 确定是否需要SQL查询
        if self.use_db:
            # 生成SQL查询
            sql_query = self.generate_sql_query(user_query)
            print(f"生成的SQL查询: {sql_query}")
            
            # 执行SQL查询
            result = self.execute_sql_query(sql_query)
        else:
            # 生成Pandas代码
            pandas_code = self.generate_pandas_code(user_query)
            print(f"生成的Pandas代码: {pandas_code}")
            
            # 执行Pandas代码
            result = self.execute_pandas_query(pandas_code)
        
        # 如果需要可视化且结果是DataFrame
        if needs_visualization and isinstance(result, pd.DataFrame):
            visualization = create_visualization(result, user_query)
            return {
                "type": "visualization",
                "data": result,
                "visualization": visualization,
                "query": user_query
            }
        
        # 生成自然语言回答
        answer = self.generate_answer(user_query, result)
        
        return {
            "type": "text",
            "data": result,
            "answer": answer,
            "query": user_query
        }
    
    def generate_answer(self, user_query, result):
        """生成自然语言回答"""
        # 创建回答生成提示模板
        answer_prompt = PromptTemplate(
            input_variables=["query", "result"],
            template="""
            你是一个数据分析专家。根据以下信息，用自然语言回答问题。
            
            用户问题: {query}
            
            查询结果:
            {result}
            
            请用简洁、专业的中文回答这个问题。解释数据中的关键发现和洞察。
            如果结果是空的或无法回答问题，请说明原因。
            
            回答:
            """
        )
        
        # 创建LLM链
        answer_chain = LLMChain(llm=self.llm, prompt=answer_prompt)
        
        # 生成回答
        answer = answer_chain.run({
            "query": user_query,
            "result": str(result)[:1000]  # 限制结果大小
        })
        
        return answer.strip()