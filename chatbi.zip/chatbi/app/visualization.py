"""
可视化模块，处理数据可视化
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import io
import base64

def create_visualization(data, query):
    """
    根据数据和查询创建可视化
    
    Args:
        data: DataFrame数据
        query: 用户查询
    
    Returns:
        base64编码的图像
    """
    try:
        # 设置样式
        sns.set(style="whitegrid")
        plt.figure(figsize=(10, 6))
        
        # 确定可视化类型
        if "分布" in query or "直方图" in query:
            # 选择数值列进行分布可视化
            numeric_cols = data.select_dtypes(include=['number']).columns
            if len(numeric_cols) > 0:
                sns.histplot(data=data, x=numeric_cols[0], kde=True)
                plt.title(f"{numeric_cols[0]}的分布")
        
        elif "趋势" in query or "时间" in query or "日期" in query:
            # 时间序列可视化
            if 'Date' in data.columns:
                # 按日期分组并计算聚合值
                if 'Total' in data.columns:
                    time_data = data.groupby('Date')['Total'].sum().reset_index()
                    plt.plot(time_data['Date'], time_data['Total'])
                    plt.title("销售总额随时间的变化")
                    plt.xticks(rotation=45)
            
        elif "比较" in query or "对比" in query:
            # 分类比较可视化
            categorical_cols = data.select_dtypes(include=['object']).columns
            numeric_cols = data.select_dtypes(include=['number']).columns
            
            if len(categorical_cols) > 0 and len(numeric_cols) > 0:
                cat_col = categorical_cols[0]
                num_col = numeric_cols[0]
                
                # 如果分类值太多，只取前10个
                if data[cat_col].nunique() > 10:
                    top_cats = data.groupby(cat_col)[num_col].sum().nlargest(10).index
                    plot_data = data[data[cat_col].isin(top_cats)]
                else:
                    plot_data = data
                
                sns.barplot(x=cat_col, y=num_col, data=plot_data)
                plt.title(f"{cat_col}与{num_col}的关系")
                plt.xticks(rotation=45)
        
        elif "相关性" in query or "关系" in query:
            # 相关性可视化
            numeric_cols = data.select_dtypes(include=['number']).columns
            if len(numeric_cols) >= 2:
                sns.scatterplot(x=numeric_cols[0], y=numeric_cols[1], data=data)
                plt.title(f"{numeric_cols[0]}与{numeric_cols[1]}的关系")
        
        else:
            # 默认可视化：如果有分类列和数值列，创建条形图
            categorical_cols = data.select_dtypes(include=['object']).columns
            numeric_cols = data.select_dtypes(include=['number']).columns
            
            if len(categorical_cols) > 0 and len(numeric_cols) > 0:
                cat_col = categorical_cols[0]
                num_col = numeric_cols[0]
                
                # 如果分类值太多，只取前10个
                if data[cat_col].nunique() > 10:
                    top_cats = data.groupby(cat_col)[num_col].sum().nlargest(10).index
                    plot_data = data[data[cat_col].isin(top_cats)]
                else:
                    plot_data = data
                
                sns.barplot(x=cat_col, y=num_col, data=plot_data)
                plt.title(f"{cat_col}与{num_col}的关系")
                plt.xticks(rotation=45)
            elif len(numeric_cols) >= 2:
                # 如果只有数值列，创建散点图
                sns.scatterplot(x=numeric_cols[0], y=numeric_cols[1], data=data)
                plt.title(f"{numeric_cols[0]}与{numeric_cols[1]}的关系")
            elif len(numeric_cols) == 1:
                # 如果只有一个数值列，创建直方图
                sns.histplot(data=data, x=numeric_cols[0], kde=True)
                plt.title(f"{numeric_cols[0]}的分布")
        
        # 调整布局
        plt.tight_layout()
        
        # 将图像转换为base64编码
        buffer = io.BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        
        # 关闭图像以释放内存
        plt.close()
        
        # 编码为base64
        graphic = base64.b64encode(image_png).decode('utf-8')
        
        return graphic
    except Exception as e:
        print(f"创建可视化时出错: {str(e)}")
        return None